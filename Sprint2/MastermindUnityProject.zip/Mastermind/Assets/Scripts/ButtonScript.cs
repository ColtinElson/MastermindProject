﻿
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class ButtonScript : MonoBehaviour
{
    public static GameObject RedPeg;
    public static GameObject YellowPeg;
    public static GameObject GreenPeg;
    public static GameObject PurplePeg;
    public static GameObject BrownPeg;
    public static GameObject BluePeg;
    public static GameObject BlackPeg;
    public static GameObject WhitePeg;
    public static GameObject[] CodeCovered;
    public static GameObject EasyBoard;
    public static GameObject MedBoard;
    public static GameObject HardBoard;
    public static GameObject EasyButton;
    public static GameObject MediumButton;
    public static GameObject HardButton;
    public Text message;
    public bool playable;

    private int xValue = -22;
    private int yValue = 280;
    private int turn = 0;

    private int[] guess = { 6, 6, 6, 6 };
    private int guessAmount = 0;
    private int maxGuess = 12;

    private int[] code = new int[4];
    private int[] guessAnswer = new int[4];

    void Start()
    {
        RedPeg = GameObject.FindGameObjectWithTag("RedPeg");
        YellowPeg = GameObject.FindGameObjectWithTag("YellowPeg");
        GreenPeg = GameObject.FindGameObjectWithTag("GreenPeg");
        PurplePeg = GameObject.FindGameObjectWithTag("PurplePeg");
        BrownPeg = GameObject.FindGameObjectWithTag("BrownPeg");
        BluePeg = GameObject.FindGameObjectWithTag("BluePeg");
        BlackPeg = GameObject.FindGameObjectWithTag("BlackPeg");
        WhitePeg = GameObject.FindGameObjectWithTag("WhitePeg");
        CodeCovered = GameObject.FindGameObjectsWithTag("codeCovered");
        EasyBoard = GameObject.FindGameObjectWithTag("12Board");
        MedBoard = GameObject.FindGameObjectWithTag("10Board");
        HardBoard = GameObject.FindGameObjectWithTag("8Board");
        EasyButton = GameObject.FindGameObjectWithTag("EasyButton");
        MediumButton = GameObject.FindGameObjectWithTag("MediumButton");
        HardButton = GameObject.FindGameObjectWithTag("HardButton");
        message = GetComponent<Text>();
        playable = false;
    }

    public void buttonPressed(Transform prefab)
    {
        if (turn < 4 && guessAmount < maxGuess && playable)
        {
            Debug.Log("You have clicked the button!");
            Instantiate(prefab, new Vector3(xValue, yValue-(60*turn), 0), prefab.transform.rotation);
    
            switch (prefab.name)
            {
                case "RedPeg":
                    guess[turn] = 0;
                    break;
                case "YellowPeg":
                    guess[turn] = 1;
                    break;
                case "GreenPeg":
                    guess[turn] = 2;
                    break;
                case "PurplePeg":
                    guess[turn] = 3;
                    break;
                case "BrownPeg":
                    guess[turn] = 4;
                    break;
                case "BluePeg":
                    guess[turn] = 5;
                    break;
                default:
                    guess[turn] = 6;
                    break;
            };
            turn++;
            
        }

    }

    public void difficultyChoice(int choice)
    {
        switch (choice)
        {
            case 1:
                maxGuess = 8;
                Instantiate(HardBoard, new Vector3(500 - (4 * 65), 200, 0), HardBoard.transform.rotation);
                break;
            case 2:
                maxGuess = 10;
                Instantiate(MedBoard, new Vector3(500 - (2 * 65), 200, 0), MedBoard.transform.rotation);
                break;
            default:
                maxGuess = 12;
                Instantiate(EasyBoard, new Vector3(500, 200, 0), EasyBoard.transform.rotation);
                break;
        };
        Start();
        Destroy(HardButton);
        Destroy(MediumButton);
        Destroy(EasyButton);
        code = generateCode();
        playable = true;
    }

    public void makeGuess()
    {
        Debug.Log("You have made a guess!");
        turn = 0;
        xValue += 65;
        guessAmount += 1;
        message.text = "Guesses Made: " + guessAmount;
        guessAnswer = checkCode(code, guess);

        bool valid = true;
        int[] xValues = { -40, -40, -10, -10 };
        int[] yValues = {35, 5, 35, 5};
        for (int i = 0; i < guessAnswer.Length; i++)
        {
            switch (guessAnswer[i])
            {
                case 1:
                    Instantiate(BlackPeg, new Vector3(xValues[i]+(guessAmount-1)*65, yValues[i], 0), BlackPeg.transform.rotation);
                    break;
                case 2:
                    Instantiate(WhitePeg, new Vector3(xValues[i]+(guessAmount-1)*65, yValues[i], 0), WhitePeg.transform.rotation);
                    valid = false;
                    break;
                default:
                    valid = false;
                    break;
            };
        }
        if (valid == true)
        {
            playable = false;
            message.text = "YOU WON!!!! CONGRATS!!!!";
            for(int i = 0; i < CodeCovered.Length; i++)
            {
                Destroy(CodeCovered[i]);
            }

        }
        else if (guessAmount == maxGuess)
        {
            playable = false;
            message.text = "Sorry, you lost!";
            for (int i = 0; i < CodeCovered.Length; i++)
            {
                Destroy(CodeCovered[i]);
            }
        }
    }

    public static int[] generateCode()
    {
        Debug.Log("Generating code!");
        int xCode = 772;
        int yCode = 268;
        System.Random rnd = new System.Random();
        int[] codeValue = new int[4];
        for (int i = 0; i < codeValue.Length; i++)
        {
            codeValue[i] = rnd.Next(0, 6);
            switch (codeValue[i])
            {
                case 0:
                    Instantiate(RedPeg, new Vector3(xCode, yCode -(76 * i), 0), RedPeg.transform.rotation);
                    break;
                case 1:
                    Instantiate(YellowPeg, new Vector3(xCode, yCode - (76 * i), 0), YellowPeg.transform.rotation);
                    break;
                case 2:
                    Instantiate(GreenPeg, new Vector3(xCode, yCode - (76 * i), 0), GreenPeg.transform.rotation);
                    break;
                case 3:
                    Instantiate(PurplePeg, new Vector3(xCode, yCode - (76 * i), 0), PurplePeg.transform.rotation);
                    break;
                case 4:
                    Instantiate(BrownPeg, new Vector3(xCode, yCode - (76 * i), 0), BrownPeg.transform.rotation);
                    break;
                case 5:
                    Instantiate(BluePeg, new Vector3(xCode, yCode - (76 * i), 0), BluePeg.transform.rotation);
                    break;
                default:
                    break;
            };
            Debug.Log(codeValue[i]);
        }
        return codeValue;
    }

    public static int[] checkCode(int[] code, int[] guess)
    {
        Debug.Log("Checking code!");

        int[] colors = { 0, 0, 0, 0, 0, 0 };

        for (int i = 0; i < code.Length; i++)
        {
            colors[(code[i])]++;
        }
  
        int[] guessAnswer = { 0, 0, 0, 0 };
        for (int i = 0; i < code.Length; i++)
        {
            if (code[i] == guess[i])
            {
                guessAnswer[i] = 1;
                colors[(code[i])] --;
            }
        }
        for (int i = 0; i < code.Length; i++)
        {
            if (code.Contains(guess[i]) == true && colors[guess[i]] > 0 && guessAnswer[i] != 1)
            {
                guessAnswer[i] = 2;
                colors[(code[i])]--;
            }
        }
        return guessAnswer;
    }

}