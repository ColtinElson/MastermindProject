﻿using System;

public class Class1
{
    private string thingy;

    {white, red, blue, purple}
    {1,2,3,4}

	public Class1()
	{
    
	}
    public string getThingy() => this.thingy;

    public void setThingy(string thing) => this.thingy = thing;
}
