﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour {

    Class1 thing = new Class1();

    // Use this for initialization
    void Start () {
        thing.setThingy("Sup");
        thing.getThingy();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
